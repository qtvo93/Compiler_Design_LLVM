#include <stdio.h>

void printVarInt(int x)
{
    printf("%d\n", x);
}

void printVarFloat(float x)
{
    printf("%f\n", x);
}
